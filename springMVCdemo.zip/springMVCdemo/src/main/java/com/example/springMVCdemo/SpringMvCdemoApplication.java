package com.example.springMVCdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvCdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvCdemoApplication.class, args);
	}

}
