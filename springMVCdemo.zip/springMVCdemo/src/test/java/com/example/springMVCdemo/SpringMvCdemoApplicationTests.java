package com.example.springMVCdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvCdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
